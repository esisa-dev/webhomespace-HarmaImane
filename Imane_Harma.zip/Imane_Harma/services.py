import os
import subprocess
from model import Dossier
import zipfile
from pathlib import Path
class Services:
    index_path: str = ""
    index_list: list = []
    _user: str = ""


    def connecter(self,username, password) -> bool:
        try:
            command = ["su", "-c", "whoami", username]
            self._user=username
            result = subprocess.run(command, input=password.encode(), capture_output=True)
            return result.returncode == 0
        except subprocess.CalledProcessError:
            return False
        
    def creer_Utilisateur(self, nomU:str, password1:str, password2:str)->str:
        result = subprocess.run(['id', '-u', nomU], stdout=subprocess.PIPE)
        if result.returncode == 0:
            return 'Utilisateur Existant!!!!!!!'
        if password1==password2:
            return 'Les mots de passe ne sont pas identiques'
        else:
            subprocess.run(['sudo', 'useradd', '-p', password1,nomU])
            return 'Utilisateur ajouté avec succés'

    def content(self, name: str) -> None:
        if self.index_path=="":
            self.index_path = "/home/" + name
        else:
            self.index_list=[]
            self.index_path += "/" + name
        output = subprocess.check_output(['sudo', 'ls', '-l', '--time-style=+%d/%m/%Y', self.index_path])
        output_lines = output.decode().split('\n')
        for l in output_lines:
            res = l.split()
            if len(res) == 7:
                self.index_list.append(Dossier(res[0], res[1], res[2], res[3], res[4],
                                            res[5] ,res[6]))

    def rechercher_by_keyword(self,keyword):
        dirs = []
        if not self.index_list:
            return []
        else:
            for i in self.index_list:
                if keyword in i.name or keyword==i :
                    dirs.append(i)
            return dirs
    
    
    def nbr_dirs(self) -> dict:
        dic={}
        dic["Dirs"]=0
        dic["Files"]=0
        dic["Space"]=0
        for i in self.index_list:
            if i.permission.startswith('d'):
                dic["Dirs"]+=1
            else:
                dic["Files"]+=1
            dic["Space"]+=int(i.taille)
        return dic
    
    def nbr_dirs_by_Keyword(self,Keyword)->dict:
        dossiers = self.rechercher_by_keyword(Keyword)
        dic={}
        dic["Dirs"]=0
        dic["Files"]=0
        dic["Space"]=0
        for i in dossiers:
            if i.permission.startswith('d'):
                dic["Dirs"]+=1
            else:
                dic["Files"]+=1
            dic["Space"]+=int(i.taille)
        return dic
    
    
    def cat_file(self,file: str) -> str:
        path = Path(file)
        if path.is_file():
            with open(file, 'r') as f:
                contenu = f.read()
            return contenu
        else:
            return "Fichier inexistant!!!!!"
    
    
    def compresser(self):
        home_dir = "/home/" + self._user
        zip_filename = self._user + ".zip"
        zip_filepath = os.path.join(home_dir, zip_filename)
        with zipfile.ZipFile(zip_filepath, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for root,dirs, files in os.walk(home_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        zip_file.write(file_path, os.path.relpath(file_path, home_dir))
                    except FileNotFoundError:
                        print(f"Ignoré le fichier {file_path} qui n'existe pas.")
        return zip_filepath
    
    
    

    