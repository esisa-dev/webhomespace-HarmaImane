class Dossier:
    def __init__(self,permission,nbrLien,nomP,nomG,taille,date,name):
        self.permission = permission
        self.nbrLien = nbrLien
        self.nomP = nomP
        self.nomG = nomG
        self.taille = taille
        self.date = date
        self.name= name
    
    def __str__(self):
        return f"{self.permission} {self.nbrLien} {self.nomP} {self.nomG} {self.taille} {self.date} {self.nom}"
 



