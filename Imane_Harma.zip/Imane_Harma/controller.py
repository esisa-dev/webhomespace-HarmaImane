from datetime import datetime
import hashlib
import logging
import os
from venv import logger
from services import Services
from flask import (
    Flask,
    request,
    render_template,
    redirect,
    send_file,
    session,
    url_for,
)


logging.basicConfig(filename='logging.log', level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
logging.info('Application started')


    
template_dir = os.path.abspath('/home/ubuntu/Desktop/Imane_Harma/Templates')
app = Flask(__name__, template_folder=template_dir, static_folder='static')
app.secret_key = "1234"
def generate_key(login):
    return hashlib.md5(str(login).encode('utf-8')).hexdigest()

@app.route('/')
def index():
    return render_template("login.html")

@app.route('/home/<name>')
def home(name):
    ser.content(name)
    if os.path.isdir(ser.index_path):
        return render_template("home.html", db=ser.index_list,Space=ser.nbr_dirs()["Space"], Dirs=ser.nbr_dirs()["Dirs"], Files=ser.nbr_dirs()["Files"],texte="")
    else :
       return render_template("home.html", db=[],Space="", Dirs="", Files="",texte=ser.cat_file(ser.index_path))

@app.route('/CreerUser', methods=['GET'])
def creer_user():
    return render_template('creer_user.html')

@app.route('/create_user', methods=['POST', 'GET'])
def create_user():
    if request.method == 'POST':
        username = request.form['username']
        password1 = request.form['password1']
        password2 = request.form['password2']
        success = ser.creer_Utilisateur(username, password1, password2)
        if success == 'Utilisateur ajouté avec succés':
            return redirect(url_for('index'))
        else:
            return render_template('creer_user.html', error_create=success)
    else:
        return render_template('creer_user.html')
@app.route('/Rechercher')
def rechercher():
    keyword = request.args.get('keyword')
    return render_template('home.html', db=ser.rechercher_by_keyword(keyword), Space=ser.nbr_dirs_by_Keyword(keyword)["Space"], Dirs=ser.nbr_dirs_by_Keyword(keyword)["Dirs"], Files=ser.nbr_dirs_by_Keyword(keyword)["Files"],text="")

@app.route('/telecharger')
def download_home_dir():
    path=ser.compresser()()
    return send_file(path, as_attachment=True)




@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    try:
        res = ser.connecter(username, password)
        if res:
            app.secret_key=generate_key(login)
            session['user_id'] = username
            response = app.make_response(redirect(url_for('home', name=username)))
            response.set_cookie('access_time', str(datetime.now()))
            logging.info('Successful login for user: %s', username)
            return response
        else:
            logging.warning('Failed login attempt for user: %s', username)
            return render_template('login.html', error_auth='login or password incorrect')
    except Exception as e:
        logging.error('Exception occurred during login: %s', str(e))
        return render_template('login.html', error_auth=str(e))



@app.route('/logout')
def logout():
    logger.info('User %s logged out', session.get('user_id'))
    ser.index_list=[]
    ser.index_path=""
    session.pop('user_id',None)
    return redirect(url_for('index'))
if __name__ == '__main__':
    ser = Services()
    logging.basicConfig(filename='logging.log', level=logging.INFO)
    app.run(host='0.0.0.0', port=8080, debug=True)
